from pathlib import Path
import csv,re,collections
p=Path('/workspace/360_materials/output/02_关键词优化对照表.csv')
norm=lambda s:re.sub(r'\s+','',s).casefold()
counts=collections.Counter()
with p.open(encoding='utf-8-sig',newline='') as f:
 for r in csv.DictReader(f):counts[norm(r['关键词'])]+=1
seen=collections.Counter();n=0;dups=0
with p.open(encoding='utf-8-sig',newline='') as f,p.with_suffix('.tmp').open('w',encoding='utf-8-sig',newline='') as out:
 rd=csv.DictReader(f);wr=csv.DictWriter(out,fieldnames=rd.fieldnames,lineterminator='\r\n');wr.writeheader()
 for r in rd:
  k=r['关键词'];key=(r['组ID'],norm(k),r['原匹配']);seen[key]+=1;action=[]
  if any(t in k for t in ['代写','买论文','购买论文','买卖论文','挂名']):action.append('建议暂停待授权；涉及代写或买论文需求')
  elif seen[key]>1:action.append('同组同词同匹配重复，建议去重待确认');dups+=1
  elif counts[norm(k)]>1:action.append('跨组或匹配重复，核对地域与路由后归并')
  if '代发' in k:action.append('代发服务含义与业务边界待核实')
  if int(r['GBK字节'])>30:action.append('长词；官方关键词上限待核实')
  if not action:action.append('保留原词；待搜索词及转化数据验证')
  r['逐词处理建议']='；'.join(action);wr.writerow(r);n+=1
p.with_suffix('.tmp').replace(p)
print('rewritten keyword rows',n,'normalized duplicate recommendations',dups)
