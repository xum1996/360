from pathlib import Path
import csv,json,re,collections,hashlib,unicodedata,sys
from openpyxl import load_workbook
B=Path('/workspace/360_materials');W=B/'work';O=B/'output';D=O/'01_360点睛物料文件'
report={'errors':[],'warnings':[],'files':{},'creative_checks':{},'statistics':{},'client_validation':'未执行；离线验证不证明客户端导入兼容或广告实际投放合规'}
def fail(s):report['errors'].append(s)
def warn(s):report['warnings'].append(s)
def b(s):return len(s.encode('gbk','strict'))
def norm(s):return re.sub(r'\s+','',s).casefold()
def readcsv(path,encoding='gb18030'):
 with path.open(encoding=encoding,newline='') as f:
  rr=csv.reader(f);hh=next(rr);out=[]
  for no,row in enumerate(rr,2):
   if len(row)!=len(hh):fail(f'{path.name}:{no}列数{len(row)}!={len(hh)}');continue
   out.append(dict(zip(hh,row)))
 return hh,out
H,source=readcsv(B/'input/source.csv')
if len(H)!=45:fail('源文件不是45列')
lookup={(r['物料类型'],r['ID']):r for r in source}
gkw=collections.defaultdict(list);groups={r['ID']:r for r in source if r['物料类型']=='推广组'}
for r in source:
 if r['物料类型']=='关键词':gkw[r['推广组ID']].append(r['关键词'])
risky_terms=['代写','买论文','购买论文','买卖论文','挂名']
riskgroups={r['推广组ID'] for r in source if r['物料类型']=='关键词' and any(t in r['关键词'] for t in risky_terms)}
emptygroups=set(groups)-set(gkw)
original_keywords={norm(r['关键词']) for r in source if r['物料类型']=='关键词'}
newgroupkw=collections.defaultdict(list)
allcsv={}
for path in sorted(D.glob('*.csv')):
 hh,data=readcsv(path)
 allcsv[path.name[0]]=(path,data)
 report['files'][path.name]={'rows':len(data),'columns':len(hh),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'encoding':'GB18030严格解码成功'}
 if hh!=H:fail(path.name+'列名或列序与原始45列不一致')
 if path.name.startswith(('A_','D_')):
  allowed={'创意标题','创意描述1','创意描述2'}
  for i,r in enumerate(data,2):
   if r['物料类型']!='创意':fail(f'{path.name}:{i}不是创意')
   old=lookup.get(('创意',r['ID']))
   if old is None:fail(f'{path.name}:{i}未知原始ID');continue
   changed={k for k in H if r[k]!=old[k]}
   if not changed<=allowed:fail(f'{path.name}:{i}改动保护字段{sorted(changed-allowed)}')
   if r['推广组ID'] in emptygroups:fail(f'{path.name}:{i}为空词组伪造创意')
   if path.name.startswith('A_') and r['推广组ID'] in riskgroups:fail(f'{path.name}:{i}敏感组进入A更新')
   if path.name.startswith('D_') and r['推广组ID'] not in riskgroups:fail(f'{path.name}:{i}非敏感组误入D')
 elif path.name.startswith('B_'):
  allowed={'推广计划否定关键词','推广计划精确否定关键词','推广组否定关键词','推广组精确否定关键词'}
  for i,r in enumerate(data,2):
   old=lookup.get((r['物料类型'],r['ID']))
   if old is None:fail(f'{path.name}:{i}未知原始ID');continue
   changed={k for k in H if r[k]!=old[k]}
   if not changed or not changed<=allowed:fail(f'{path.name}:{i}更改范围有误{changed}')
   for field in changed:
    before=old[field].split(';') if old[field] else []
    after=r[field].split(';') if r[field] else []
    cursor=iter(before)
    if not all(any(x==y for x in cursor) for y in after):fail(f'{path.name}:{i}否定变更非有序删除')
 elif path.name.startswith('C_'):
  statusfield={'推广计划':'推广计划启用/暂停','推广组':'推广组启用/暂停','关键词':'关键词启用/暂停','创意':'创意启用/暂停'}
  for i,r in enumerate(data,2):
   if any(r[k] for k in ['ID','推广计划ID','推广组ID','关键词ID','创意ID']):fail(f'{path.name}:{i}候选虚构或带旧ID')
   sf=statusfield.get(r['物料类型'])
   if sf is None or r[sf]!='暂停':fail(f'{path.name}:{i}候选状态不是暂停')
   if r['物料类型']=='关键词':newgroupkw[(r['推广计划名称'],r['推广组名称'])].append(r['关键词'])
  if '禁止直接导入' not in path.name:fail('C文件未在名称明确禁止直接导入')
for k in ['A','B','C','D']:
 if k not in allcsv:fail('缺少'+k+'类CSV')
A=allcsv.get('A',(None,[]))[1];C=allcsv.get('C',(None,[]))[1];Dr=allcsv.get('D',(None,[]))[1]
aids={r['创意ID'] for r in A};dids={r['创意ID'] for r in Dr}
if aids & dids:fail('A与D创意ID交叉')
maxes=collections.defaultdict(int);counts=collections.Counter();examples=[]
for origin,rr in [('A现有更新',A),('D敏感组草案',Dr),('C新增候选',[r for r in C if r['物料类型']=='创意'])]:
 for r in rr:
  title=r['创意标题'];d1=r['创意描述1'];d2=r['创意描述2'];matches=re.findall(r'\{([^{}]+)\}',title)
  identity=r['创意ID'] or r['推广计划名称']+'/'+r['推广组名称']+'/'+title
  vals=newgroupkw[(r['推广计划名称'],r['推广组名称'])] if origin.startswith('C') else gkw[r['推广组ID']]
  counts[origin]+=1
  if len(matches)!=1:fail(origin+':通配符不是一个'+identity);continue
  default=matches[0]
  if default not in vals:fail(origin+':默认词不在本组'+identity)
  try:
   sizes={'标题':b(title),'默认展开':b(title.replace('{'+default+'}',default)),'描述1':b(d1),'描述2':b(d2),'拼接':b(d1+d2)}
   if not vals:fail(origin+':关键词组空'+identity);continue
   # Check every actual member; conservative result includes braces again.
   dynamic=[b(title.replace('{'+default+'}',kw)) for kw in vals]
   sizes['全组动态']=max(dynamic);sizes['动态含括号']=max(dynamic)+2
   counts['实际逐词动态替换检查次数']+=len(vals)
   for field,n in sizes.items():maxes[field]=max(maxes[field],n)
   if sizes['标题']>45 or sizes['全组动态']>45 or sizes['动态含括号']>45:fail(origin+':标题或动态超限'+identity)
   if sizes['描述1']>70 or sizes['描述2']>70 or sizes['拼接']>70:fail(origin+':描述或拼接超限'+identity)
  except UnicodeError:fail(origin+':不可GBK编码'+identity)
  if any(t in ''.join([title,d1,d2]) for t in ['包录用','保证录用','确保快速见刊','绿色通道','3~7天审稿','快至次月见刊','1~3个月见刊']):fail(origin+':含结果保证或缺证时效'+identity)
report['creative_checks']={'counts':dict(counts),'max_gbk_bytes':dict(maxes),'empty_keyword_groups_excluded':len(emptygroups),'sensitive_groups_excluded_from_A':len(riskgroups)}
newkeys=[r['关键词'] for r in C if r['物料类型']=='关键词']
newnorm=[norm(k) for k in newkeys]
hits=sorted(set(newnorm)&original_keywords)
dups=[k for k,n in collections.Counter(newnorm).items() if n>1]
if hits:fail('新增候选与原账户规范化重复:'+str(hits[:15]))
if dups:fail('新增候选内部规范化重复:'+str(dups[:15]))
# Full keyword traceability map.
kp=O/'02_关键词优化对照表.csv'
if kp.exists():
 kh,kr=readcsv(kp,'utf-8-sig');origkw=[r for r in source if r['物料类型']=='关键词']
 if len(kr)!=len(origkw):fail('02关键词对照行数不符')
 if {r['关键词ID'] for r in kr}!={r['关键词ID'] for r in origkw}:fail('02关键词ID覆盖不符')
 for r in kr:
  old=lookup.get(('关键词',r['关键词ID']))
  if old:
   checks={'关键词':'关键词','原匹配':'关键词匹配方式','本次匹配':'关键词匹配方式','原状态及本次状态':'关键词启用/暂停','原出价及本次出价':'关键词出价','原链接及本次链接':'关键词链接网址','原移动链接及本次链接':'关键词移动链接网址'}
   for newfield,oldfield in checks.items():
    if r[newfield]!=old[oldfield]:fail('02关键词保护数据不符:'+r['关键词ID']+'/'+newfield)
 duplicate_counts=collections.Counter((r['推广组ID'],norm(r['关键词']),r['关键词匹配方式']) for r in origkw)
 expected_duplicate_excess=sum(n-1 for n in duplicate_counts.values() if n>1)
 actual_duplicate_recommendations=sum('同组同词同匹配重复' in r['逐词处理建议'] for r in kr)
 if expected_duplicate_excess!=actual_duplicate_recommendations:fail('02同组重复建议计数不符:'+str(actual_duplicate_recommendations)+'!='+str(expected_duplicate_excess))
 report['files'][kp.name]={'rows':len(kr),'columns':len(kh),'encoding':'UTF-8 BOM','normalization':'去除全部空白+casefold','duplicate_excess_expected':expected_duplicate_excess,'duplicate_recommendations':actual_duplicate_recommendations}
else:fail('缺少02关键词优化对照表')
for path in sorted(O.glob('*.xlsx')):
 try:
  wb=load_workbook(path,read_only=True,data_only=False)
  detail={}
  for ws in wb:
   count=0;formula=0
   for row in ws.iter_rows():
    count+=1
    formula+=sum(c.data_type=='f' for c in row)
   detail[ws.title]={'rows_including_header':count,'declared_max_rows':ws.max_row,'columns':ws.max_column,'formula_cells':formula}
   if formula:warn(path.name+'/'+ws.title+'有公式，需检查是否来自文本注入')
  report['files'][path.name]={'xlsx_read_success':True,'sheets':detail}
  wb.close()
 except Exception as e:fail('Excel损坏或不可读:'+path.name+':'+str(e))
statsfile=W/'delivery_stats.json'
if statsfile.exists():
 stats=json.load(statsfile.open());report['statistics']=stats
 expected={'rewritten_existing':len(A)+len(Dr),'import_existing_creative_updates':len(A),'withheld_rewritten_risky_group':len(Dr),'candidate_rows':len(C),'candidate_plans':sum(r['物料类型']=='推广计划' for r in C),'candidate_groups':sum(r['物料类型']=='推广组' for r in C),'candidate_keywords':len(newkeys),'candidate_creatives':sum(r['物料类型']=='创意' for r in C),'empty_groups':len(emptygroups),'empty_group_creatives':sum(r['物料类型']=='创意' and r['推广组ID'] in emptygroups for r in source)}
 for k,n in expected.items():
  if stats.get(k)!=n:fail('统计不符:'+k+':'+str(stats.get(k))+'!='+str(n))
 sha=hashlib.sha256((B/'input/source.csv').read_bytes()).hexdigest()
 if stats.get('source_sha256')!=sha:fail('源文件摘要变化')
else:fail('缺少delivery_stats.json')
# Validate review workbooks expected rows when sheets present.
f4=report['files'].get('04_创意标题与描述优化对照表.xlsx',{}).get('sheets',{})
if f4.get('全部7700条对照',{}).get('rows_including_header')!=7701:fail('04完整创意对照不是7700数据行')
f3=report['files'].get('03_新增行业及长尾关键词清单.xlsx',{}).get('sheets',{})
for sh,n in [('计划候选',15),('组候选',84),('新增498词',499),('新增249创意',250)]:
 if f3.get(sh,{}).get('rows_including_header')!=n:fail('03新增sheet行数不符:'+sh)
# C is deliberately incomplete, so make this limitation explicit in machine report too.
report['candidate_missing_fields']={'plan_budget':sum(r['物料类型']=='推广计划' and not r['推广计划预算'] for r in C),'group_bid':sum(r['物料类型']=='推广组' and not r['推广组出价'] for r in C),'keyword_landing_url':sum(r['物料类型']=='关键词' and not r['关键词链接网址'] for r in C),'creative_landing_url':sum(r['物料类型']=='创意' and not r['创意链接网址'] for r in C),'interpretation':'人为保留待确认字段；C为暂停草案，禁止直接导入，不能宣称账户必填已完成'}
report['passed']=not report['errors']
(W/'final_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'passed':report['passed'],'errors':report['errors'],'warnings':report['warnings'],'creative_checks':report['creative_checks'],'candidate_missing_fields':report['candidate_missing_fields']},ensure_ascii=False,indent=2))
sys.exit(0 if report['passed'] else 1)
