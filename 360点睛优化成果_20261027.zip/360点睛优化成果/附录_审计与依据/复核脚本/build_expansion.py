import csv,json,pathlib,re
B=pathlib.Path('/workspace/360_materials')
with (B/'input/source.csv').open(encoding='gb18030',newline='') as f:
 source={r['关键词'].strip() for r in csv.DictReader(f) if r['物料类型']=='关键词'}
# Subject selections are coverage candidates, not proof of supplied service or search demand.
catalog=[
('教育教学','候选-教育教学',['幼儿教育','中小学教育','高等教育','职业教育','教育管理','体育教学']),
('医学护理','候选-医学护理',['临床医学','护理','中医药','医学检验','医学影像','医院管理']),
('财会与金融','候选-财会金融',['财务管理','会计','审计','税务','金融','内部控制']),
('建筑施工','候选-建筑施工',['建筑工程','土木工程','施工管理','工程监理','建筑材料','建筑安全']),
('工程造价与设计','候选-造价设计',['工程造价','工程预算','BIM技术','建筑设计','结构设计','城市规划']),
('水利水电','候选-水利水电',['水利工程','水资源管理','水文工程','水电站工程','水利施工','水利信息化']),
('电力与电气','候选-电力电气',['电力工程','电气工程','电力系统','输变电','新能源发电','储能技术']),
('交通工程','候选-交通工程',['交通运输','公路工程','道路桥梁','铁路工程','轨道交通','智能交通']),
('计算机与信息','候选-计算机信息',['软件工程','计算机科学','信息技术','大数据','人工智能','网络安全']),
('机械与自动化','候选-机械自动化',['机械制造','机械设计','机电工程','自动化控制','智能制造','工业机器人']),
('农业与环境','候选-农业环境',['农业技术','畜牧兽医','林业','园艺','食品科学','环境保护']),
('经济与企业管理','候选-经济企业管理',['经济学','企业管理','人力资源管理','市场营销','物流管理','供应链管理']),
('法律与公共管理','候选-法律公共管理',['法学','行政管理','公共管理','社会治理','公共政策']),
('其他专业领域','候选-其他专业',['能源工程','矿业工程','化工','材料科学','测绘','图书情报']),
]
endings=['论文投稿','期刊投稿','职称论文投稿','论文发表咨询','期刊推荐','期刊投稿咨询','论文投稿要求','期刊审稿周期','论文投稿流程','期刊投稿要求','论文投什么期刊','职称论文发表咨询']
seen=set(source); dedup=[]; result=[]; all_keywords=[]
def n(s):return len(s.encode('gbk','strict'))
for industry,plan,subjects in catalog:
 groups=[]
 for s in subjects:
  words=[]
  for e in endings:
   w=s+e
   if w in seen:
    dedup.append({'industry':industry,'subject':s,'keyword':w,'reason':'原账户已有' if w in source else '新增候选内重复'})
    continue
   seen.add(w);words.append(w)
   if len(words)==6:break
  if not words:continue
  shortest=min(words,key=n)
  texts=[
   ('期刊方向咨询',f'{s}选刊，先核对研究方向。','提交选题，咨询投稿要求。'),
   ('核对投稿要求',f'{s}投稿材料与流程咨询。','先核对要求，再确定投稿安排。'),
   ('了解投稿流程',f'{s}论文，咨询选刊思路。','结合专业方向，了解投稿步骤。'),
  ]
  creatives=[]
  for suffix,d1,d2 in texts:
   title='{'+shortest+'}'+suffix
   assert n(title)<=45,(s,title,n(title))
   assert n(d1)<=70 and n(d2)<=70 and n(d1+d2)<=70,(s,d1,d2,n(d1+d2))
   assert all(n(title.replace('{'+shortest+'}',w))<=45 for w in words)
   creatives.append({'title':title,'desc1':d1,'desc2':d2})
  groups.append({'name':s+'投稿咨询','subject':s,'keywords':words,'creatives':creatives})
  all_keywords+=words
 result.append({'industry':industry,'plan':plan,'groups':groups})
assert len(all_keywords)==len(set(all_keywords))
assert not (set(all_keywords)&source)
(B/'work/expansion.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
summary={'行业数量':len(result),'新增候选计划数量':len(result),'新增候选组数量':sum(len(i['groups']) for i in result),'新增候选关键词数量':len(all_keywords),'新增候选创意数量':sum(len(g['creatives']) for i in result for g in i['groups']),'去重候选数量':len(dedup),'去重详情':dedup,'状态':'待验证、建议暂停、不直接导入草案','搜索需求':'未验证，不代表实际搜索量','服务覆盖':'未验证，新增领域须业务方确认','原账户唯一关键词数':len(source),'最长原始标题字节':max(n(c['title']) for i in result for g in i['groups'] for c in g['creatives']),'最长动态替换标题字节':max(n(c['title'].replace(re.search(r'\{[^{}]+\}',c['title']).group(0),w)) for i in result for g in i['groups'] for c in g['creatives'] for w in g['keywords']),'最长两描述拼接字节':max(n(c['desc1']+c['desc2']) for i in result for g in i['groups'] for c in g['creatives']),'行业统计':[{'行业':i['industry'],'推广组':len(i['groups']),'关键词':sum(len(g['keywords']) for g in i['groups']),'创意':sum(len(g['creatives']) for g in i['groups'])} for i in result]}
(B/'work/expansion_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in summary.items() if k not in ['去重详情','行业统计']},ensure_ascii=False,indent=2))
