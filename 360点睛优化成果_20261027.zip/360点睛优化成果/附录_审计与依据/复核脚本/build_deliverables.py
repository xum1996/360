from pathlib import Path
import csv,json,collections,re,hashlib,zipfile
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter
B=Path('/workspace/360_materials'); O=B/'output'; W=B/'work'
with open(B/'input/source.csv',encoding='gb18030',newline='') as f:
 reader=csv.DictReader(f); H=reader.fieldnames; rows=list(reader)
for n,r in enumerate(rows,2): r['_row']=n
plans={r['ID']:r for r in rows if r['物料类型']=='推广计划'}
groups={r['ID']:r for r in rows if r['物料类型']=='推广组'}
kw=[r for r in rows if r['物料类型']=='关键词']; cr=[r for r in rows if r['物料类型']=='创意']
gkw=collections.defaultdict(list)
for r in kw:gkw[r['推广组ID']].append(r)
def bl(s):return len(s.encode('gbk',errors='strict'))
def writecsv(p,headers,data,enc='utf-8-sig'):
 with open(p,'w',encoding=enc,newline='') as f:
  w=csv.writer(f,lineterminator='\r\n');w.writerow(headers)
  for r in data:w.writerow([r.get(k,'') for k in headers] if isinstance(r,dict) else r)
def book(p,sheets):
 wb=Workbook();wb.remove(wb.active)
 for title,headers,data in sheets:
  ws=wb.create_sheet(title[:31]);ws.append(headers)
  for row_number,row in enumerate(data,2):
   vals=[row.get(k,'') for k in headers] if isinstance(row,dict) else row
   ws.append(vals)
   for col_number in range(1,len(headers)+1):
    c=ws.cell(row_number,col_number)
    if isinstance(c.value,str):c.data_type='s'
  ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
  for c in ws[1]:c.font=Font(color='FFFFFF',bold=True);c.fill=PatternFill('solid',fgColor='234E70')
  for i,h in enumerate(headers,1):ws.column_dimensions[get_column_letter(i)].width= min(58,max(14,bl(h)+3))
 wb.save(p)
# Ordered specific professional domains; general keywords remain explicitly unsorted, not force-labelled.
DOMAINS=[
 ('教育教学',['幼儿教育','学前教育','中小学教育','高等教育','职业教育','教育管理','教育心理','体育教学','学科教学','语文','数学','英语','教育','教学','教师']),
 ('医学护理',['临床医学','护理','中医学','中药学','药学','医学检验','医学影像','医院管理','康复','口腔','公共卫生','神经','心血管','影像','检验','妇产','肿瘤','中医','中药','医疗','医学','药师','医师','护师','医药','卫生']),
 ('财会与金融',['财务管理','会计','审计','税务','银行','金融','内部控制','企业成本','财务信息化','财务']),
 ('工程造价与设计',['工程造价','工程预算','BIM','建筑设计','结构设计','市政设计','城市规划','工程咨询','造价']),
 ('水利水电',['水利工程','水资源管理','水文工程','水电站','水利施工','水利信息化','水利','水电','水文']),
 ('电力与电气',['电力工程','电气工程','电力系统','输变电','电网运行','新能源发电','储能技术','电力','电气','电网']),
 ('交通工程',['交通运输','公路工程','道路桥梁','铁路工程','轨道交通','交通管理','智能交通','公路','桥梁','交通','铁路']),
 ('计算机与信息',['软件工程','计算机科学','信息技术','大数据','人工智能','通信工程','网络安全','软件平台','计算机','通信','信息化']),
 ('机械与自动化',['机械制造','机械设计','机电工程','自动化控制','智能制造','工业机器人','设备维护','机械','自动化','机电']),
 ('农业与环境',['农业技术','畜牧兽医','食品科学','环境保护','生态工程','农学','农业','林业','园艺','环境','畜牧','兽医','食品','生态']),
 ('建筑施工',['建筑工程','土木工程','施工管理','工程监理','建筑材料','工程项目管理','建筑安全','建筑','土木','施工','监理']),
 ('经济与企业管理',['经济学','工商管理','企业管理','人力资源','市场营销','物流管理','供应链管理','经济','管理']),
 ('法律与公共管理',['法学','行政管理','公共管理','社会治理','公共政策','法律','法治']),
 ('其他专业领域',['能源','矿业','地质','化工','材料','测绘','档案','图书情报','文化艺术','旅游管理','文学','艺术','图书','新闻','博物馆'])]
# Prefer public management over broad 管理.
DOMAINS.insert(0,DOMAINS.pop(12))
def classify(s):
 for industry,terms in DOMAINS:
  for t in terms:
   if t.lower() in s.lower():return industry,t
 return '通用或待分行业','通用'
def intent(s):
 if any(t in s for t in ['代写','买论文','购买论文','买卖论文','挂名']):return '敏感需求待处理'
 for title,terms in [('投稿咨询',['咨询']),('职称投稿',['职称','评职','副高','中级','正高']),('核心投稿',['核心','SCI','sci','EI','CSSCI']),('周期咨询',['审稿','见刊','加急','快速']),('投稿需求',['投稿','发表','征稿','选刊'])]:
  if any(t in s for t in terms):return title
 return '信息检索待验证'
def sensitive(s):return any(t in s for t in ['代写','买论文','购买论文','买卖论文','挂名'])
riskgroups={r['推广组ID'] for r in kw if sensitive(r['关键词'])}
# Actual edits will be limited to creative text and negative fields, never account settings.
creative_changes=[]; creative_compare=[]; deferred=[]; rewrite_audit=[]; import_creatives=[]
shortlist=[]; creative_per_group=collections.Counter(); group_cache={}
for r in cr:
 gid=r['推广组ID']; members=gkw[gid]; old=[r['创意标题'],r['创意描述1'],r['创意描述2']]
 out={k:r[k] for k in H}; new=['','','']; reason=''; maxdyn=''; default=''; status=''
 if not members:
  status='阻断：组未导出关键词';reason='缺少真实本组词，不能凭组名伪造通配词；须补充完整关键词导出'
  deferred.append(r)
 else:
  if gid not in group_cache:
   values=list(dict.fromkeys(x['关键词'] for x in members)); maxlen=max(map(bl,values))
   clean=[k for k in values if not sensitive(k) and not any(t in k for t in ['代发','包录','包发','保录','快速','加急','见刊快'])]
   if not clean:clean=[k for k in values if not sensitive(k)]
   clean.sort(key=lambda k:(0 if '投稿' in k else 1,0 if '论文' in k else 1,bl(k),k))
   subjectset={classify(k)[1] for k in values}
   subject=next(iter(subjectset)) if len(subjectset)==1 and '通用' not in subjectset else ''
   group_cache[gid]=(values,maxlen,clean,subject)
  values,maxlen,clean,subject=group_cache[gid]
  n=creative_per_group[gid];creative_per_group[gid]+=1
  original_defaults=re.findall(r'\{([^{}]+)\}',old[0])
  default=next((k for k in original_defaults if k in clean), clean[(n//5)%len(clean)])
  suffixes=[['期刊匹配咨询','选刊咨询','咨询'],['核对投稿要求','投稿咨询','咨询'],['了解审稿流程','流程咨询','咨询'],['职称投稿咨询','选刊咨询','咨询'],['咨询期刊方向','投稿咨询','咨询']]
  variant=n%5
  if variant==3 and not all(any(t in k for t in ['职称','评职','副高','中级','正高','教授','讲师','护师','医师']) for k in values):variant=1
  suffix=next((s for s in suffixes[variant] if maxlen+bl(s)+2<=45),'')
  title='{'+default+'}'+suffix
  templates=[('按研究方向，咨询期刊选择。','先核对投稿要求，再安排投稿。'),('投稿材料与期刊要求咨询。','结合研究方向，了解投稿流程。'),('咨询审稿环节与投稿流程。','周期以期刊实际处理为准。'),('核对评审文件中的期刊要求。','按专业方向咨询投稿安排。'),('选刊先看主题与栏目要求。','提供研究方向，咨询投稿步骤。')]
  d1,d2=templates[variant]
  if subject:
   d1=subject+'投稿咨询，核对期刊要求。'
   if bl(d1+d2)>70:d1,d2=templates[variant]
  new=[title,d1,d2];maxdyn=maxlen+bl(suffix)
  assert bl(title)<=45 and maxdyn<=45 and maxlen+bl(suffix)+2<=45
  assert bl(d1)<=70 and bl(d2)<=70 and bl(d1+d2)<=70
  assert default in values
  for f,v in zip(['创意标题','创意描述1','创意描述2'],new):out[f]=v
  status='已重写；客户端预检前不投放'
  if gid in riskgroups:status='已重写但暂不输出更新：本组含敏感关键词'
  reason='保留ID及全部账户设置；标题默认词为本组现有词；按全组最长词缩短后缀；时效缺证转为咨询流程'
  creative_changes.append(out)
  if gid not in riskgroups:import_creatives.append(out)
  if n<5:shortlist.append([r['推广计划名称'],r['推广组名称'],r['创意ID'],new[0],new[1],new[2],['期刊匹配','投稿要求','审稿流程','评审要求或匹配','投稿步骤'][variant],status])
  rewrite_audit.append({'来源':'原有创意','计划':r['推广计划名称'],'组':r['推广组名称'],'创意ID':r['创意ID'],'默认词':default,'标题字节含括号':bl(title),'默认展开字节':bl(default+suffix),'全组动态最大':maxdyn,'全组含括号保守最大':maxdyn+2,'描述1字节':bl(d1),'描述2字节':bl(d2),'拼接字节':bl(d1+d2),'检查关键词数':len(members),'默认词在本组':'是','处理状态':status})
 creative_compare.append([r['_row'],r['推广计划ID'],gid,r['创意ID'],r['推广计划名称'],r['推广组名称'],*old,*new,*map(bl,old),*[bl(v) if v else '' for v in new],maxdyn,default,status,reason])
print('rewritten',len(creative_changes),'importable subset',len(import_creatives),'deferred',len(deferred),'riskgroups',len(riskgroups),flush=True)
# Full keyword optimization map; no changes to match/state when performance evidence is absent.
seen=collections.Counter(); text_counts=collections.Counter(re.sub(r'\s+','',r['关键词']).casefold() for r in kw)
industry_counts=collections.Counter(); recommendation_counts=collections.Counter(); kwmap=[]
for r in kw:
 k=r['关键词'];industry,subject=classify(k); it=intent(k); key=(r['推广组ID'],re.sub(r'\s+','',k).casefold(),r['关键词匹配方式']);seen[key]+=1
 industry_counts[industry]+=1
 action=[]
 if sensitive(k):action.append('建议暂停待授权；涉及代写或买论文需求')
 elif seen[key]>1:action.append('同组同词同匹配重复，建议去重待确认')
 elif text_counts[re.sub(r'\s+','',k).casefold()]>1:action.append('跨组或匹配重复，核对地域与路由后归并')
 if '代发' in k:action.append('代发服务含义与业务边界待核实')
 if bl(k)>30:action.append('长词；官方关键词上限待核实')
 if not action:action.append('保留原词；待搜索词及转化数据验证')
 recommendation_counts['；'.join(action)]+=1
 kwmap.append([r['_row'],r['推广计划ID'],r['推广组ID'],r['关键词ID'],r['推广计划名称'],r['推广组名称'],k,bl(k),r['关键词匹配方式'],r['关键词匹配方式'],r['关键词启用/暂停'],r['关键词出价'],r['关键词链接网址'],r['关键词移动链接网址'],industry,subject,it,'建议-'+industry,subject+'-'+it,'；'.join(action),'原词、ID、匹配、出价、链接、状态均未改；结构迁移未执行','搜索潜力待验证；未提供成本或转化报告'])
writecsv(O/'02_关键词优化对照表.csv',['源CSV行号','计划ID','组ID','关键词ID','原计划','原组','关键词','GBK字节','原匹配','本次匹配','原状态及本次状态','原出价及本次出价','原链接及本次链接','原移动链接及本次链接','行业初分','专业初分','意图初分','建议计划_未执行','建议组_未执行','逐词处理建议','实际变更范围','数据依据'],kwmap)
# Primary creative comparison workbook.
book(O/'04_创意标题与描述优化对照表.xlsx',[
 ('全部7700条对照',['源CSV行号','计划ID','组ID','创意ID','计划','组','原标题','原描述1','原描述2','新标题','新描述1','新描述2','原标题字节','原描1字节','原描2字节','新标题字节','新描1字节','新描2字节','全组动态最大','真实默认词','状态','原因'],creative_compare),
 ('每组前五条测试候选',['计划','组','现有创意ID','标题','描述1','描述2','测试方向','状态'],shortlist),
 ('使用说明',['事项','说明'],[['覆盖','7700条原始创意全部对照；3225条有词创意重写；无词组不伪造标题'],['状态','所有原创意状态保持；前五条仅为测试建议，未暂停其他创意'],['描述拼接','新创意两描述拼接也<=70；此为保守策略，不代表已核实客户端映射'],['效果','未做线上AB实验，无点击或转化提升承诺']])])
# New material candidates; IDs not invented and operational fields intentionally left blank.
exp=json.load(open(W/'expansion.json'));newrows=[];expkw=[];expcr=[];expg=[];expp=[]
for plan in exp:
 pn=plan['plan'];account=rows[0]['推广账户']
 p={k:'' for k in H};p.update({'物料类型':'推广计划','推广账户':account,'推广计划名称':pn,'推广计划启用/暂停':'暂停'})
 newrows.append(p);expp.append([plan['industry'],pn,'暂停','待确认真实服务覆盖、预算、地域、时段和设备；不继承原计划预算'])
 for group in plan['groups']:
  gn=group['name'];g={k:'' for k in H};g.update({'物料类型':'推广组','推广账户':account,'推广计划名称':pn,'推广组名称':gn,'推广组启用/暂停':'暂停'});newrows.append(g)
  expg.append([plan['industry'],pn,gn,group['subject'],len(group['keywords']),len(group['creatives']),'暂停','组出价及投放业务待补，不假定服务可用'])
  for k in group['keywords']:
   v={k:'' for k in H};v.update({'物料类型':'关键词','推广账户':account,'推广计划名称':pn,'推广组名称':gn,'关键词':k,'关键词匹配方式':'精确','关键词启用/暂停':'暂停'});newrows.append(v)
   expkw.append([plan['industry'],pn,gn,k,bl(k),'精确','暂停','新增长尾候选；原有关键词集合去重','搜索量与潜力待验证','业务覆盖、出价及落地页待确认'])
  for c in group['creatives']:
   v={k:'' for k in H};v.update({'物料类型':'创意','推广账户':account,'推广计划名称':pn,'推广组名称':gn,'创意标题':c['title'],'创意描述1':c['desc1'],'创意描述2':c['desc2'],'创意启用/暂停':'暂停'});newrows.append(v)
   expcr.append([plan['industry'],pn,gn,c['title'],c['desc1'],c['desc2'],bl(c['title']),bl(c['desc1']),bl(c['desc2']),bl(c['desc1']+c['desc2']),'暂停','候选，未投放'])
   default=re.findall(r'\{([^{}]+)\}',c['title'])[0];suffix=c['title'].replace('{'+default+'}','');mx=max(bl(k)+bl(suffix) for k in group['keywords'])
   rewrite_audit.append({'来源':'新增暂停候选','计划':pn,'组':gn,'创意ID':'未创建','默认词':default,'标题字节含括号':bl(c['title']),'默认展开字节':bl(default+suffix),'全组动态最大':mx,'全组含括号保守最大':mx+2,'描述1字节':bl(c['desc1']),'描述2字节':bl(c['desc2']),'拼接字节':bl(c['desc1']+c['desc2']),'检查关键词数':len(group['keywords']),'默认词在本组':'是','处理状态':'暂停候选；字段待补，不可直接导入'})
book(O/'03_新增行业及长尾关键词清单.xlsx', [('计划候选',['行业','计划','状态','待确认'],expp),('组候选',['行业','计划','组','专业','候选词数','候选创意数','状态','待确认'],expg),('新增498词',['行业','计划','组','关键词','GBK字节','匹配','状态','来源','需求证据','待确认'],expkw),('新增249创意',['行业','计划','组','标题','描述1','描述2','标题字节','描述1字节','描述2字节','拼接字节','状态','标记'],expcr)])
# Strict schema import files, encoded like original; delta files contain NO added audit columns.
D=O/'01_360点睛物料文件';D.mkdir(exist_ok=True)
writecsv(D/'A_现有创意更新_客户端预检.csv',H,import_creatives,'gb18030')
writecsv(D/'C_新增行业暂停草案_待补字段_禁止直接导入.csv',H,newrows,'gb18030')
writecsv(D/'D_敏感关键词组创意重写_暂不导入.csv',H,[r for r in creative_changes if r['推广组ID'] in riskgroups],'gb18030')
json.dump({'creative_compare':creative_compare,'rewrite_audit':rewrite_audit,'industry_counts':dict(industry_counts),'riskgroups':list(riskgroups),'import_creative_ids':[r['创意ID'] for r in import_creatives]},open(W/'build_results.json','w'),ensure_ascii=False)
json.dump({'original_rows':len(rows),'original_types':dict(collections.Counter(r['物料类型'] for r in rows)),'rewritten_existing':len(creative_changes),'import_existing_creative_updates':len(import_creatives),'withheld_rewritten_risky_group':len(creative_changes)-len(import_creatives),'empty_groups':sum(g not in gkw or not gkw[g] for g in groups),'empty_group_creatives':len(deferred),'candidate_plans':len(expp),'candidate_groups':len(expg),'candidate_keywords':len(expkw),'candidate_creatives':len(expcr),'candidate_rows':len(newrows),'risky_keywords_unique_rows':sum(sensitive(r['关键词']) for r in kw),'risky_groups':len(riskgroups),'industry_counts':dict(industry_counts),'source_sha256':hashlib.sha256((B/'input/source.csv').read_bytes()).hexdigest()},open(W/'delivery_stats.json','w'),ensure_ascii=False,indent=2)
print('base deliverables generated',flush=True)
