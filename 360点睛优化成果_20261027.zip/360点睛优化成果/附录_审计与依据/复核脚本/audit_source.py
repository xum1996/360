import csv,json,re,collections,pathlib,urllib.parse
B=pathlib.Path('/workspace/360_materials/work')
def byt(s):
 try:return len(s.encode('gbk'))
 except UnicodeEncodeError:return sum(1 if ord(c)<128 else 2 for c in s)
def dump(name,rows):
 if not rows:return
 with (B/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
with open('/workspace/360_materials/input/source.csv',encoding='gb18030',newline='') as f:
 rr=csv.DictReader(f); fields=rr.fieldnames; rows=list(rr)
types=collections.defaultdict(list)
for r in rows:types[r['物料类型']].append(r)
plans={r['推广计划ID']:r for r in types['推广计划']}; groups={r['推广组ID']:r for r in types['推广组']}
kw=types['关键词']; cr=types['创意']; kg=collections.defaultdict(list);cg=collections.defaultdict(list)
for r in kw:kg[r['推广组ID']].append(r)
for r in cr:cg[r['推广组ID']].append(r)
issues=[]
for i,r in enumerate(rows,2):
 t=r['物料类型'];pid=r['推广计划ID'];gid=r['推广组ID']
 for why in ([] if pid in plans else ['计划ID缺失']):issues.append({'行':i,'类型':t,'ID':r['ID'],'问题':why})
 if t!='推广计划':
  if gid not in groups:issues.append({'行':i,'类型':t,'ID':r['ID'],'问题':'组ID缺失'})
  elif groups[gid]['推广计划ID']!=pid:issues.append({'行':i,'类型':t,'ID':r['ID'],'问题':'组计划关联错'})
 for col,d in [('推广计划名称',plans.get(pid)),('推广组名称',groups.get(gid))]:
  if d and r[col]!=d[col]:issues.append({'行':i,'类型':t,'ID':r['ID'],'问题':col+'不一致'})
 idcol={'推广计划':'推广计划ID','推广组':'推广组ID','关键词':'关键词ID','创意':'创意ID'}[t]
 if r['ID']!=r[idcol]:issues.append({'行':i,'类型':t,'ID':r['ID'],'问题':'通用ID与类型ID不一致'})
# duplicates
normal=lambda s:re.sub(r'\s+','',s).casefold()
byw=collections.defaultdict(list); bysame=collections.defaultdict(list)
for r in kw:byw[normal(r['关键词'])].append(r);bysame[(r['推广组ID'],normal(r['关键词']),r['关键词匹配方式'])].append(r)
dups=[]
for k,v in byw.items():
 if len(v)>1:dups.append({'关键词':v[0]['关键词'],'行数':len(v),'组数':len(set(r['推广组ID'] for r in v)),'计划数':len(set(r['推广计划ID'] for r in v)),'精确行':sum(r['关键词匹配方式']=='精确' for r in v),'短语行':sum('短语' in r['关键词匹配方式'] for r in v),'样例ID':';'.join(r['关键词ID'] for r in v[:10])})
# negative direct literal audit (may not prove platform actual matching)
negcounts=[]; negdups=[]; negconf=[]; negstats=collections.Counter(); termhits=collections.Counter()
for typ,idx,cols in [('推广计划',plans,['推广计划否定关键词','推广计划精确否定关键词']),('推广组',groups,['推广组否定关键词','推广组精确否定关键词'])]:
 for id,r in idx.items():
  for col in cols:
   terms=[x.strip() for x in r[col].split(';') if x.strip()];c=collections.Counter(terms)
   negcounts.append({'类型':typ,'ID':id,'名称':r['推广计划名称']+'/'+r['推广组名称'],'字段':col,'数量':len(terms),'去重数量':len(c),'超过100':len(terms)>100,'超过200':len(terms)>200})
   negstats[col]+=len(terms)
   for term,n in c.items():
    if n>1:negdups.append({'类型':typ,'ID':id,'字段':col,'词':term,'重复数':n})
for r in kw:
 p=plans[r['推广计划ID']];g=groups[r['推广组ID']];text=r['关键词'];low=text.casefold(); hits=[]
 for rr,col in [(p,'推广计划否定关键词'),(p,'推广计划精确否定关键词'),(g,'推广组否定关键词'),(g,'推广组精确否定关键词')]:
  isexact='精确' in col
  for term in rr[col].split(';'):
   if term and ((low==term.casefold()) if isexact else (term.casefold() in low)):
    hits.append(col+':'+term);termhits[col+':'+term]+=1
 if hits:negconf.append({'计划ID':r['推广计划ID'],'组ID':r['推广组ID'],'关键词ID':r['关键词ID'],'关键词':text,'匹配方式':r['关键词匹配方式'],'状态':r['关键词启用/暂停'],'潜在拦截':';'.join(hits),'判断':'文字包含模拟，须客户端搜索词诊断核实'})
# creative
creative=[];ct=collections.Counter();riskterms=['包录用','保录用','确保','保证','100%','绿色通道','当月录用','极速','见刊快','快速发表','审稿快','加急见刊','内部关系','全网','第一','最权威','免审','当天','3~7','3-7','次月','1~3','1-3']
for r in cr:
 gid=r['推广组ID'];words=[x['关键词'] for x in kg[gid]];title=r['创意标题'];matches=re.findall(r'\{([^{}]+)\}',title)
 good=bool(matches) and all(x in words for x in matches)
 dyn=[]
 for w in words:
  dyn.append(byt(re.sub(r'\{[^{}]+\}',w,title)))
 b=[byt(r[x]) for x in ['创意标题','创意描述1','创意描述2']]
 flags=[]
 for val,lim,label in zip(b,[45,70,70],['标题超限','描述1超限','描述2超限']):
  if val>lim:flags.append(label);ct[label]+=1
 if not matches:flags.append('无通配符');ct['无通配符']+=1
 elif not good:flags.append('默认词非本组关键词');ct['默认词非本组关键词']+=1
 if dyn and max(dyn)>45:flags.append('动态标题存在超限');ct['动态标题存在超限']+=1
 risk=[x for x in riskterms if x in ''.join(r[y] for y in ['创意标题','创意描述1','创意描述2'])]
 if risk:ct['风险表达创意']+=1
 creative.append({'计划ID':r['推广计划ID'],'组ID':gid,'创意ID':r['创意ID'],'标题':title,'标题字节':b[0],'描述1字节':b[1],'描述2字节':b[2],'默认词':';'.join(matches),'默认词在本组':good,'动态标题最大字节':max(dyn) if dyn else None,'标题默认词替换字节':byt(re.sub(r'\{([^{}]+)\}',lambda m:m[1],title)),'描述拼接字节':b[1]+b[2],'字段问题':';'.join(flags),'风险词':';'.join(risk)})
# links
linkcols=['关键词链接网址','关键词移动链接网址','创意显示网址','创意链接网址','创意移动显示网址','创意移动链接网址'];links=collections.Counter();badlinks=[]
for r in kw+cr:
 for col in linkcols:
  u=r[col]
  if u:
   links[(col,u)]+=1
   pp=urllib.parse.urlsplit(u)
   if pp.scheme not in ['http','https'] or not pp.netloc or re.search(r'[\s{}]',u):badlinks.append({'类型':r['物料类型'],'ID':r['ID'],'字段':col,'网址':u,'问题':'URL结构或空白/占位符待核实'})
# plan & group overview
ps=[];gs=[]
for pid,p in plans.items():
 g=[r for r in groups.values() if r['推广计划ID']==pid]; kws=[r for r in kw if r['推广计划ID']==pid]; cs=[r for r in cr if r['推广计划ID']==pid]
 ps.append({'计划ID':pid,'计划':p['推广计划名称'],'组数':len(g),'关键词数':len(kws),'唯一词数':len(set(normal(r['关键词']) for r in kws)),'创意数':len(cs),'状态':p['推广计划启用/暂停'],'预算':p['推广计划预算'],'移动比例':p['推广计划移动搜索出价比例']})
for gid,g in groups.items():
 v=kg[gid];crs=cg[gid];lens=[byt(x['关键词']) for x in v]
 gs.append({'计划ID':g['推广计划ID'],'计划':g['推广计划名称'],'组ID':gid,'组':g['推广组名称'],'关键词数':len(v),'唯一词数':len(set(normal(x['关键词']) for x in v)),'最短词字节':min(lens) if lens else None,'最长词字节':max(lens) if lens else None,'45字节以上词数':sum(x>45 for x in lens),'创意数':len(crs),'状态':g['推广组启用/暂停'],'出价':g['推广组出价'],'样例词':';'.join(x['关键词'] for x in v[:5])})
# ID dup counts
ids={t:sum(n-1 for n in collections.Counter(r['ID'] for r in v).values() if n>1) for t,v in types.items()}
summary={'row_count':len(rows),'column_count':len(fields),'types':{t:len(v) for t,v in types.items()},'duplicate_ids':ids,'reference_issue_count':len(issues),'keyword_unique_normalized':len(byw),'duplicate_keyword_text_count':len(dups),'duplicate_keyword_excess_rows':sum(x['行数']-1 for x in dups),'duplicate_same_group_match_key_count':sum(len(v)>1 for v in bysame.values()),'duplicate_same_group_match_excess_rows':sum(len(v)-1 for v in bysame.values() if len(v)>1),'match_distribution':dict(collections.Counter(r['关键词匹配方式'] for r in kw)),'creative_checks':dict(ct),'keyword_max_bytes':max(byt(r['关键词']) for r in kw),'keywords_over_30':sum(byt(r['关键词'])>30 for r in kw),'keywords_over_40':sum(byt(r['关键词'])>40 for r in kw),'keywords_over_45':sum(byt(r['关键词'])>45 for r in kw),'negative_counts':dict(negstats),'negative_literal_collision_keyword_rows':len(negconf),'negative_collision_top_terms':termhits.most_common(30),'negative_duplicate_entries':sum(x['重复数']-1 for x in negdups),'bad_link_structure_count':len(badlinks),'unique_link_values_by_field':dict(collections.Counter(k[0] for k in links)),'states':{t:dict(collections.Counter(r[{'推广计划':'推广计划启用/暂停','推广组':'推广组启用/暂停','关键词':'关键词启用/暂停','创意':'创意启用/暂停'}[t]] for r in v)) for t,v in types.items()},'notes':['负词冲突按大小写不敏感字面包含/相等模拟，不证明实际平台触发','创意长度按 GBK 可编码字符字节；不可编码字符回退双字节并待平台复核','无搜索词/成本/转化数据，不能推断实际投放表现']}
(B/'audit_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
for name,rs in [('audit_plans.csv',ps),('audit_groups.csv',gs),('audit_duplicates.csv',dups),('audit_negative_counts.csv',negcounts),('audit_negative_duplicates.csv',negdups),('audit_negative_collisions.csv',negconf),('audit_creatives.csv',creative),('audit_reference_issues.csv',issues),('audit_bad_links.csv',badlinks)]:dump(name,rs)
print(json.dumps(summary,ensure_ascii=False,indent=2))
print('PLANS',json.dumps(ps,ensure_ascii=False))
print('GROUP_MAX',sorted(gs,key=lambda r:r['关键词数'],reverse=True)[:5])
