from pathlib import Path
import csv,json,collections,hashlib,shutil,zipfile
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill
from openpyxl.utils import get_column_letter
B=Path('/workspace/360_materials');W=B/'work';O=B/'output';D=O/'01_360点睛物料文件'
def j(name):return json.load(open(W/name))
def readcsv(p,enc='utf-8-sig'):
 with open(p,encoding=enc,newline='') as f:
  rd=csv.reader(f);h=next(rd);return h,list(rd)
def book(p,sheets):
 wb=Workbook();wb.remove(wb.active)
 for title,h,data in sheets:
  ws=wb.create_sheet(title[:31]);ws.append(h)
  for i,r in enumerate(data,2):
   ws.append([r.get(k,'') for k in h] if isinstance(r,dict) else r)
   for col_number in range(1,len(h)+1):
    c=ws.cell(i,col_number)
    if isinstance(c.value,str):c.data_type='s'
  ws.freeze_panes='A2';ws.auto_filter.ref=f'A1:{get_column_letter(len(h))}{len(data)+1}'
  for c in ws[1]:c.font=Font(color='FFFFFF',bold=True);c.fill=PatternFill('solid',fgColor='234E70')
  for i,col in enumerate(h,1):ws.column_dimensions[get_column_letter(i)].width=min(60,max(14,len(col)*2+2))
 wb.save(p)
with open(B/'input/source.csv',encoding='gb18030',newline='') as f:
 rd=csv.DictReader(f);H=rd.fieldnames;rows=list(rd)
S=j('delivery_stats.json');R=j('build_results.json');A=j('audit_summary.json');C=j('audit_compliance_summary.json');N=j('negative_summary.json');U=j('negative_updates.json')
modified={}
for u in U:
 idx=u['source_row']-2
 if idx not in modified:modified[idx]=rows[idx].copy()
 assert modified[idx][u['field']]==u['old']
 modified[idx][u['field']]=u['new']
with open(D/'B_否定词字段更新_客户端预检.csv','w',encoding='gb18030',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=H,lineterminator='\r\n');wr.writeheader();wr.writerows(modified.values())
S['negative_modified_entities']=len(modified);S['negative_modified_fields']=len(U);S['negative_removed_occurrences']=N['removed_occurrences'];S['negative_added_applied']=0;S['negative_added_pending']=N['new_suggestions_unapplied']
S['existing_keyword_actual_modifications']=0;S['existing_keyword_paused_or_deleted']=0;S['existing_plan_or_group_moves']=0
S['existing_keyword_same_group_duplicate_recommendations']=A['duplicate_same_group_match_excess_rows']
S['creative_checks_executed']=len(R['rewrite_audit']);S['dynamic_substitution_checks']=sum(r['检查关键词数'] for r in R['rewrite_audit']);S['rewritten_length_failures']=0
# Audit workbook retains original findings and complete checks for rewritten material.
base_checks=[['原始记录数',S['original_rows'],'45列完整'],['原始标题超45',A['creative_checks']['标题超限'],'用户指定限制，非已核平台当前限额'],['原始描述1超70',A['creative_checks']['描述1超限'],'同上'],['原始描述2超70',A['creative_checks']['描述2超限'],'同上'],['原始动态标题存在超限',A['creative_checks']['动态标题存在超限'],'仅有真实关键词可模拟范围'],['无通配符',A['creative_checks']['无通配符'],'原始标题'],['默认词不在组内',A['creative_checks']['默认词非本组关键词'],'含无关键词组；不与无通配符数简单相加'],['已重写有词创意',S['rewritten_existing'],'全部GBK及全组动态通过'],['新增候选创意',S['candidate_creatives'],'全部GBK及全组动态通过'],['本次校验创意',S['creative_checks_executed'],'改写及新增总数；不包含无法重写的4475条'],['逐关键词动态替换覆盖次数',S['dynamic_substitution_checks'],'含同词不同ID的记录，按创意逐条覆盖'],['重写创意长度超限',0,'标题45/描述70/拼接70及保守括号计数均通过'],['原始ID及关联异常',A['reference_issue_count'],'未发现'],['结果保证型表达',C['counts']['结果保证型_明确需改'],'表达规则筛查；非平台处罚或法律结论'],['具体时效待证',C['counts']['具体时效_待证'],'创意行计数'],['笼统时效待证',C['counts']['笼统时效_待证'],'与其他分类可重叠'],['原始URL格式异常',A['bad_link_structure_count'],'仅语法检查；落地页被代理403，未验证内容'],['否定冲突模拟关键词行',A['negative_literal_collision_keyword_rows'],'按字面模拟，不等于实际平台拦截'],['未改投放控制字段','预算/出价/地域/时段/状态/链接','原有行保持'],['平台实际审核与客户端导入','未执行','未登录/未上传账户；禁止宣称100%可导入']]
audit_sheets=[('审核结论',['项目','数量或结果','口径'],base_checks),('全部重写及新增校验',list(R['rewrite_audit'][0]),R['rewrite_audit'])]
for title,name in [('原始创意长度','audit_creatives.csv'),('原始合规表达','audit_compliance_detail.csv'),('否定冲突模拟','audit_negative_collisions.csv'),('原始重复词','audit_duplicates.csv'),('原始否定数量','audit_negative_counts.csv')]:
 h,d=readcsv(W/name);audit_sheets.append((title,h,d))
book(O/'07_广告合规与字节长度审核报告.xlsx',audit_sheets)
# Manual confirmation list is concrete, traceable and does not invent missing data.
kw=[r for r in rows if r['物料类型']=='关键词']; groups=[r for r in rows if r['物料类型']=='推广组'];has_kw={r['推广组ID'] for r in kw};cct=collections.Counter(r['推广组ID'] for r in rows if r['物料类型']=='创意')
sensitive=lambda k:any(t in k for t in ['代写','买论文','购买论文','买卖论文','挂名'])
manual=[['P0','官方规则','四个360官方URL均代理403','开放open.e.360.cn正常访问后重核限额、通配符及字段定义','未核验现行规则'],['P0','客户端版本和预检','导出CSV无版本元信息','确认客户端版本、45列全账户CSV导入方式、差量更新按ID行为，先本地预检','未客户端验证'],['P0','178个无词组','4475条创意缺真实默认词依据','补导出组内关键词；不凭组名或其他组造默认词','原创意保留在04对照但未写入更新CSV'],['P0','6个含敏感需求词的组','16个唯一关键词行含代写或购买论文需求','先确认暂停或移除敏感目标词的授权，再重测本组动态通配；不要直接导入D','原状态保持，D为阻断草案'],['P0','新增14行业服务能力','无实际资源与可交付服务证明','逐行业确认可提供投稿咨询、收稿范围及业务边界','498词与249创意均为暂停候选'],['P0','新增必需配置','新增ID/预算/组出价/URL等未填','在客户端使用新增流程分配ID；按业务确认预算、出价、地域、设备、时段、落地页和业务类目','C禁止直接导入'],['P0','落地页一致性','http及https根域访问403，6237个关键词URL未逐页请求','核对目标网址可用、咨询服务范围、资质、隐私说明及文字一致性','原链接未改'],['P1','长关键词限额','28113条原关键词GBK>30，最大40；官方词上限未知','客户端核对是否可用，未把30当现行官方上限','逐词字节见02'],['P1','否定词限额','修改后单字段最多232项','核对账户等级、计划/组、精确/短语分别上限及超额处理','不可臆定200为当前上限'],['P1','可能用于跨组路由的精确否定','198个出现项保留','核对搜索词与实际承接组，排除有意路由后再删','详见05'],['P0','动态插入代发词的业务边界','A文件33个组含9621条代发关键词，808条创意可能动态替换','逐词确认仅为合法投稿咨询与流程服务；不涉及代写、买卖署名或绕过同行评审','不能称完整合规已验证；08代发表全量核实'],['P1','历史成效数据','无搜索词、点击、成本、咨询或有效线索报告','用真实效果复核泛词、重复词、否定词、匹配和测试优先级','未编造搜索量或收益'],['P1','测试创意数量','每组当前8至46条且启用状态未动','在客户端选每组3至5条测试，需自行确认其余创意是否暂停','前五条仅候选，不宣称已AB验证']]
evidence=[['快速审稿','未提供','对应期刊、环节、日期、公开说明或可追溯记录','本次未用于广告承诺；可咨询审稿流程'],['3~7天审稿','未提供','明确是初审/初步反馈/完整同行评审；样本、适用条件与时段','未使用；不得暗示全流程7天录用'],['快至次月见刊','未提供','最快案例、实际见刊时间、期刊及适用条件；不得以检索时间替代','未使用；个例不能普遍化'],['1~3个月见刊','未提供','具体期刊近期见刊记录、计算起点、适用稿件与例外','未使用；不保证所有稿件可达'],['原有具体时效表达','1143条创意命中','逐条核对04及07；以相应刊物和环节为单位','可重写部分已转为流程表述，阻断部分未伪称修复']]
empty=[[g['推广计划ID'],g['ID'],g['推广计划名称'],g['推广组名称'],cct[g['ID']],'补充完整关键词导出；不能造通配符'] for g in groups if g['ID'] not in has_kw]
risky=[[r['推广计划ID'],r['推广组ID'],r['关键词ID'],r['推广计划名称'],r['推广组名称'],r['关键词'],r['关键词启用/暂停'],'原状态未改；建议另行授权暂停或移除；相关组D阻断'] for r in kw if sensitive(r['关键词'])]
daifa=[[r['关键词ID'],r['推广计划名称'],r['推广组名称'],r['关键词'],'代发不等于代写；需核对服务含义与合规业务边界；原词状态未改'] for r in kw if '代发' in r['关键词']]
book(O/'08_需要人工确认的营销承诺与字段清单.xlsx',[('处理优先级',['级别','项目','实际依据','需要确认的操作','当前状态'],manual),('四类时效证据',['卖点','证据状态','所需可核实证据','处理'],evidence),('178个无词组',['计划ID','组ID','计划','组','创意数','阻断原因'],empty),('16条敏感需求关键词',['计划ID','组ID','关键词ID','计划','组','关键词','原状态','处理'],risky),('代发用语业务边界',['关键词ID','计划','组','关键词','处理'],daifa)])
# Count candidate allocation by industry and retain original grouping summaries.
exp=j('expansion.json'); new_counts={p['industry']:(len(p['groups']),sum(len(g['keywords']) for g in p['groups']),sum(len(g['creatives']) for g in p['groups'])) for p in exp}
industry_table='\n'.join('|'+i+'|'+str(S['industry_counts'].get(i,0))+'|'+'|'.join(map(str,new_counts[i]))+'|' for i in new_counts)
plan_summary=[]
for p in [r for r in rows if r['物料类型']=='推广计划']:
 pid=p['ID'];ct=collections.Counter(r['物料类型'] for r in rows if r['推广计划ID']==pid)
 plan_summary.append(f"|{pid}|{p['推广计划名称']}|{ct['推广组']}|{ct['关键词']}|{ct['创意']}|")
report=f'''# 账户结构优化报告

本次实际处理用户提供的全账户CSV：GB18030编码、CRLF换行、45列、204,562条物料。原件SHA256：`{S['source_sha256']}`。没有登录账户、上传物料或启动投放。

## 原始账户与实际修改

|指标|原始|本次离线成果|
|---|---:|---|
|计划|27|原计划不移动、不改ID；另提供14个暂停候选计划|
|推广组|311|原组不移动；另提供83个暂停候选组|
|关键词|196,524|196,524条逐词分类、去重建议与处理对照；原词和匹配实际修改0|
|新增关键词|0|498个全局去重候选，均暂停，未导入|
|删除或暂停原关键词|0|实际0；16个敏感需求词、262个同组重复额外行列待确认|
|创意|7,700|有词组3,225条重写；其中A文件{S['import_existing_creative_updates']}条，D文件{S['withheld_rewritten_risky_group']}条因敏感词阻断；无词组4,475条未伪造改写|
|新增创意|0|249条暂停候选|
|否定词|36,494个出现项|{len(modified)}实体、90字段离线改写，删除533个出现项/58种词；新增应用0、另提6条建议|

关键词未擅自改状态、匹配方式、出价或链接；原计划预算、地域、时段、设备与投放状态保持。重构建议存入02逐词映射，未将旧关键词ID挪到新组。若后续采纳全部候选，结构数量将为41计划、394组；这只是方案数量，当前账户没有因此新增。

## 结构设计与行业覆盖

原账户不仅有教育、医学，也有工程、SCI、职称及大量按关键词或编号划分的组。原196,524条词中，133个组含关键词，178个组没有导出关键词。部分原组跨学科，不能以其中一条词的学科替代全组。已有词按关键词文本初分行业，不以计划名当成服务能力证明；规则分类会重叠，当前表采用明确优先级选一个类别，需业务复核。

|行业|原词初分行数|候选组数|候选关键词|候选创意|
|---|---:|---:|---:|---:|
{industry_table}

其他通用或待分行业原词：{S['industry_counts'].get('通用或待分行业',0):,}。14行业均为候选覆盖，未假定全部已有资源。每个新组围绕一个专业及投稿咨询需求，6个去重新词、3套创意。未新增SCI/核心资源承诺，未虚构搜索量。新词只代表语义合理的待验证机会，不等同于已验证的需求。

## 关键词、匹配和重复处理

原匹配：196,519精确、5短语；名称中的“短语”不代表字段实际是短语。没有成效数据，不把它们擅自改为广泛或短语。新增候选统一建议精确匹配并暂停，预计可控制语义扩张，实际流量与成本未知。

按去除全部空白并忽略大小写归并，同组同词同匹配重复额外262行；全账户规范化重复额外14,442行。这是离线文本归并口径，不代表客户端实际判重结果。跨组重复可能对应不同地域或路由，不自动删除。02逐词列出建议归属专业/意图组、原字段和未执行原因。含“代发”的9,631行独立核实，不把所有“代发”直接认定为代写。含代写或购买论文需求的16个唯一关键词行见08，相关6组的{S['withheld_rewritten_risky_group']}条重写创意只在D草案，不进入A更新文件。

## 创意及测试执行范围

3,225条有词创意逐条重写，保留原创意ID及状态；标题每条包含本组真实词，按本组全部关键词核验动态替换。新文案围绕期刊选择、投稿要求、审稿环节、投稿步骤；职称版仅在全组词都有职称特征时使用，混杂组使用通用咨询文案，避免动态替换后学科错配。因保留旧创意数量与状态，提供每组前五条作为测试候选，但未擅自暂停其余创意，也未宣称已完成线上AB实验。

全部重写及新增的3,474条创意按严格GBK检查标题<=45、描述各<=70，并额外控制描述拼接<=70和动态含括号保守值<=45；拼接处理是降低未知字段映射风险的保守策略，不是现行官方接口结论。4,475条无词组创意保留完整原文及阻断原因，不能宣称已修复。四类优先时效词没有刊物、环节和案例证据，本次转为真实投稿咨询表述；08留有证据清单，资料齐全后可恢复适用卖点。

## 否定词

按层级、短语/精确字段分别维护原清单。删除直接投稿流程/要求类误伤词，或无同计划其他组承接的明确正向词自屏蔽；不全删“免费、官网、查询”，不根据猜测新增广泛否定。保留198个可能跨组路由的精确否定出现项待核实。原有10,159条关键词有字面否定冲突模拟，不能当作平台实际不展示证据。应用本次离线修改后仍有10,101行字面冲突，完全解除58行、新增0行；并未消除全部误伤风险，详见补充审计；05保留全部原始36,494个逐词项。

## 原计划逐项统计

|计划ID|计划|组|关键词|创意|
|---|---|---:|---:|---:|
'''+'\n'.join(plan_summary)+f'''

## 导入与未解决项

A、B保留原45列和GB18030编码，按原ID组织差量更新，均需客户端本地导入预检；A只含可建立真实词关联且无敏感词组阻断的创意。B包含否定词字段更新，其他列保持。C是新增暂停草案，ID未杜撰、必需运行字段未臆填，禁止直接导入；D是敏感组重写草案，需先处理关键词阻断。04和08覆盖无词组，未把缺词创意伪装成可导入行。

四个指定360官方URL被代理403，`open.e.360.cn`需正常访问后重核现行规则；官网网页未成功读取。客户端版本、否定词数量/名称限额、新增字段识别、CSV差量更新方式及实际审核结果均未核验。落地页也被代理403，无法证明页面内容与服务一致。没有依据请求提高预算、调整出价或开启投放。

建议先核实08的P0事项，在客户端备份后本地预检A、B，复核ID关联和不会新增/改投放状态，再按账户权限自行决定提交。C须逐行业确认资源、填写必需配置并通过新增流程预检；D须先解决敏感关键词。没有客户端预检结果前，不把任何文件称为100%兼容或已上线。
'''
(O/'06_账户结构优化报告.md').write_text(report,encoding='utf-8')
(D/'导入前必读.md').write_text(f'''# 导入前必读

所有CSV保留原45列、GB18030编码、CRLF。不要一次性导入整个文件夹。

- A：{S['import_existing_creative_updates']}条现有创意更新，按ID保留全部设置，只改标题与双描述。先客户端本地预检，确认是更新而非新增。
- B：{len(modified)}条计划/组实体的否定词字段更新，共90字段；只改否定列表，其他所有字段保持。先看05的删词依据与路由保留记录。
- C：14计划、83组、498关键词、249创意的暂停草案。ID不杜撰、预算/出价/落地页等待确认字段空白，**禁止直接导入**。新增字段/父子关联方式还需客户端确认。
- D：{S['withheld_rewritten_risky_group']}条原有创意重写草案，因6个组包含16条敏感需求词，**暂不导入**；先处理目标关键词，再重核动态替换。
- 另有178组4,475条创意因未导出关键词，未输出更新行，见04/08；须补充真实组词后处理。

A、B仅是原结构的离线更新文件，未做客户端导入试验。已校验列、ID、保护字段和文案字节，不等于平台审核通过。客户端版本、规则、否定数量上限、链接内容及服务资源仍需确认。原链接与投放状态未变；新增候选全部暂停。没有对线上账户做任何改动。
''',encoding='utf-8')
# Appendices and reproducibility scripts are review aids, never account execution commands.
P=O/'附录_审计与依据';P.mkdir(exist_ok=True)
for name in ['audit_summary.json','audit_compliance_summary.json','negative_summary.json','expansion_summary.json','audit_groups.csv','audit_plans.csv','audit_negative_collisions.csv','negative_postcheck.json','audit_negative_collisions_after.csv']:
 shutil.copy2(W/name,P/name)
shutil.copytree(B/'reference',P/'官方访问记录',dirs_exist_ok=True)
S['new_title_max']=max(x['标题字节含括号'] for x in R['rewrite_audit']);S['new_dynamic_max']=max(x['全组动态最大'] for x in R['rewrite_audit']);S['new_concat_max']=max(x['拼接字节'] for x in R['rewrite_audit'])
json.dump(S,open(W/'delivery_stats.json','w'),ensure_ascii=False,indent=2);json.dump(S,open(P/'交付统计.json','w'),ensure_ascii=False,indent=2)
print(json.dumps(S,ensure_ascii=False,indent=2),flush=True)
