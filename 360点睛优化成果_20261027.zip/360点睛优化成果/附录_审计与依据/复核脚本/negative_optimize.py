from pathlib import Path
import csv,json,collections,re
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill,Alignment
from openpyxl.utils import get_column_letter
BASE=Path('/workspace/360_materials')
rows=list(csv.DictReader(open(BASE/'input/source.csv',encoding='gb18030',newline='')))
positive_plan=collections.defaultdict(set);positive_group=collections.defaultdict(set);keyword_groups_by_plan=collections.defaultdict(set)
for r in rows:
 if r['物料类型']=='关键词':
  positive_plan[r['推广计划ID']].add(r['关键词'].casefold())
  positive_group[r['推广组ID']].add(r['关键词'].casefold())
  keyword_groups_by_plan[(r['推广计划ID'],r['关键词'].casefold())].add(r['推广组ID'])
# Deliberately leave generic queries, website navigational phrases and ambiguous free-price searches unchanged.
flow_terms={'投稿须知','投稿要求','审稿流程','征稿启事','征稿','官网投稿','在线投稿','官方网站投稿','投稿系统','远程投稿系统','格式','格式要求','写作格式'}
risky_terms={'免费','便宜','最低价','白菜价','官网','官方网站','官网首页','网站','网址','查询','查询系统','查询入口','目录','目录查询','期刊目录','期刊查询','刊号查询','检索','收录','收录查询','编辑部','编辑部电话','编辑部联系方式','编辑部邮箱','杂志社电话','杂志社邮箱','自己发','自己投','难不难','怎么回复审稿人','拒稿怎么办','修改意见','预警','预警期刊','避坑','靠谱吗','怎么样','知网','万方','维普','研究生','硕士','博士','本科','中小学','小学','初中','高中','高等教育','基础教育','义务教育','学前教育','特殊教育','继续教育','班主任','中小学教师','幼师'}
explicit=re.compile(r'(论文|期刊|杂志).*(投稿|发表)|(投稿|发表).*(论文|期刊|杂志)')
updates=[];full=[];tokens=[];modified=[];risks=[];routing_pending=[]
count_by=collections.Counter()
for source_row,r in enumerate(rows,2):
 if r['物料类型'] not in ('推广计划','推广组'):continue
 isplan=r['物料类型']=='推广计划';level='计划' if isplan else '推广组';id_=r['推广计划ID'] if isplan else r['推广组ID']
 scope=positive_plan[id_] if isplan else positive_group[id_]
 fields=['推广计划否定关键词','推广计划精确否定关键词'] if isplan else ['推广组否定关键词','推广组精确否定关键词']
 for field in fields:
  old=r[field];parts=old.split(';') if old else [];removed=[];kept=[];reasons=[]
  exact='精确' in field
  for n,raw in enumerate(parts,1):
   t=raw.strip();why=''
   if not exact and t in flow_terms:
    why='直接涉及投稿要求、流程或格式咨询；原短语否定可能阻断服务相关需求，移除该精确词项以放开测试；未依据效果数据判断收益。'
   elif exact and t.casefold() in scope and explicit.search(t) and (isplan or not (keyword_groups_by_plan[(r['推广计划ID'],t.casefold())] - {r['推广组ID']})):
    why='本作用范围存在完全同词正向关键词，且明确包含投稿/发表需求；精确否定造成直接自我屏蔽。若原意为跨组路由，应先确认该正向词归属后再恢复排除。'
   if why:
    removed.append(raw);reasons.append(why);count_by['removed_total']+=1;count_by['removed_unique:'+t]+=1
    modified.append([source_row,level,id_,r['推广计划名称'],r['推广组名称'],field,'精确否定' if exact else '短语否定',t,'删除',why,'离线拟应用；未上传账户'])
   else:
    kept.append(raw)
    route_risk=exact and not isplan and t.casefold() in scope and explicit.search(t) and bool(keyword_groups_by_plan[(r['推广计划ID'],t.casefold())] - {r['推广组ID']})
    if route_risk:
     routing_pending.append([source_row,level,id_,r['推广计划名称'],r['推广组名称'],field,t,'保留原精确否定',','.join(sorted(keyword_groups_by_plan[(r['推广计划ID'],t.casefold())]-{r['推广组ID']})),'正向同词亦位于同计划其他组，可能是有意跨组路由；没有搜索/转化数据，暂不删除，仅待确认'])
    if t in risky_terms or (exact and t.casefold() in scope):
     direct=t.casefold() in scope
     reason=('本组正向同词同时存在同计划其他组，可能为跨组路由；暂保留精确否定，需确认目标承接组。' if route_risk else '与本范围正向关键词同词，但缺少明确投稿咨询上下文；保留精确否定，需搜索词与转化数据判断。') if direct else '可能拦截投稿咨询相关变体，也可能屏蔽导航/资料流量；无历史报告，暂保留，不按字面全部删除。'
     risks.append([source_row,level,id_,r['推广计划名称'],r['推广组名称'],field,t,'保持原值',reason])
   tokens.append([source_row,level,id_,r['推广计划名称'],r['推广组名称'],field,n,t,'删除' if why else '保留',why])
  new=';'.join(kept)
  maxb=max((len(t.encode('gbk')) for t in kept if t),default=0)
  full.append([source_row,level,id_,r['推广计划名称'],r['推广组名称'],field,old,new,len(parts),len(kept),maxb,'未核实官方数量/长度限额；客户端待复核'])
  if removed:
   updates.append({'source_row':source_row,'field':field,'old':old,'new':new,'removed':removed,'reason':'；'.join(dict.fromkeys(reasons)),'after_count':len(kept),'after_max_gbk_bytes':maxb})
   count_by['changed_fields']+=1
# pending only; do not apply keyword negatives based on speculation.
suggest=[
 ['论文代写','短语否定','计划级','不提供论文代写；原部分组已有“代写”，先查重与服务范围','待确认；未加入导入文件'],
 ['购买现成论文','短语否定','计划级','论文买卖意图与合法投稿咨询无关','待确认；未加入导入文件'],
 ['买卖作者署名','短语否定','计划级','署名买卖意图与正常投稿咨询无关','待确认；未加入导入文件'],
 ['伪造论文数据','短语否定','计划级','伪造学术成果意图与正常投稿咨询无关','待确认；未加入导入文件'],
 ['免费下载论文全文','精确否定','计划级','单纯全文资料下载需求；避免短语否定“免费”误伤','需先核对搜索词消耗及无效线索；未加入'],
 ['论文下载软件购买','精确否定','推广组级','软件采购意图；仅对不提供此服务且实际出现的组适用','需搜索词证据；未加入']]
wb=Workbook();wb.remove(wb.active)
def sheet(name,headers,data,widths=None):
 ws=wb.create_sheet(name);ws.append(headers)
 for r in data:ws.append(r)
 ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
 for c in ws[1]:c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='245B78')
 for i,h in enumerate(headers,1):ws.column_dimensions[get_column_letter(i)].width=(widths or {}).get(h,min(max(len(h)*2,14),40))
 return ws
sheet('说明',['项目','内容'],[
 ['处理范围','27个计划、311个推广组的全部4类否定字段，源字符串与原顺序保留可追溯。'],
 ['原始编码','GB18030可严格解码；否定词采用GBK严格计数字节。'],
 ['应用边界','仅生成离线变更，不在线上传或启动投放；其余账户字段均不改。'],
 ['删除策略','短语否定仅移除明确投稿流程/要求/格式词；精确否定仅移除作用范围内同词且明确投稿/发表的直接冲突；同计划其他组亦有该词时保留原否定，列路由待确认。'],
 ['保留策略','免费/官网/查询以及无明确投稿意图的泛词否定暂保留；跨组路由需人工确认。'],
 ['新增建议','新增候选均未应用，先核对已有层级覆盖、真实搜索词、业务范围和误伤再决定。'],
 ['效果限制','没有消耗/点击/转化报告，不能推断解除屏蔽后的流量质量、转化提升或成本变化。'],
 ['官方限额','官方网页网络403，否定数量、长度、匹配语义及客户端版本兼容性未完成在线核验。'],
 ['编号规则','source_row从CSV首条数据行2开始，包含表头后的逻辑记录号。']])
sheet('完整原始清单',['源行','层级','实体ID','计划','推广组','字段','原始否定完整串','修改后否定完整串','原数量','修改后数量','修改后单词最大GBK字节','限额核验'],full,{'原始否定完整串':90,'修改后否定完整串':90})
sheet('原始逐词追溯',['源行','层级','实体ID','计划','推广组','字段','原序号','否定词','动作','原因'],tokens,{'原因':80})
sheet('逐项修改',['源行','层级','实体ID','计划','推广组','字段','原匹配类型','否定词','动作','原因','执行状态'],modified,{'原因':90})
sheet('精确路由待确认',['源行','层级','实体ID','计划','推广组','字段','原精确否定词','动作','同计划其他承接组ID','复核理由'],routing_pending,{'复核理由':95})
sheet('新增建议未应用',['候选否定词','建议匹配方式','建议层级','依据','状态'],suggest,{'依据':90,'状态':70})
sheet('风险保留项',['源行','层级','实体ID','计划','推广组','字段','原否定词','动作','风险及复核理由'],risks,{'风险及复核理由':95})
wb.save(BASE/'output/05_否定关键词增删修改表.xlsx')
json.dump(updates,open(BASE/'work/negative_updates.json','w'),ensure_ascii=False,indent=2)
summary={'source_entity_count':338,'source_fields':len(full),'source_negative_occurrences':len(tokens),'modified_fields':len(updates),'removed_occurrences':len(modified),'removed_unique_words':len(set(r[7] for r in modified)),'new_suggestions_unapplied':len(suggest),'risk_kept_occurrences':len(risks),'routing_pending_kept_occurrences':len(routing_pending),'applied_additions':0,'all_after_counts':[{'source_row':u['source_row'],'field':u['field'],'after_count':u['after_count'],'after_max_gbk_bytes':u['after_max_gbk_bytes']} for u in updates]}
json.dump(summary,open(BASE/'work/negative_summary.json','w'),ensure_ascii=False,indent=2)
print({k:v for k,v in summary.items() if k!='all_after_counts'})
print('Workbook output',BASE/'output/05_否定关键词增删修改表.xlsx')
